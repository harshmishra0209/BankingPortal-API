package com.webapp.bankingportal.dto;

public record LoginRequest(String identifier, String password) {
}
